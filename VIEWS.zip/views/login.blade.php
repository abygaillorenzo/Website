<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<link rel="icon" href="image/logo.png">
	<link href="/css/design.css" rel="stylesheet">
</head>
<header>
	<nav id="nav"><br>
				<a class="Home" href="/home">Home</a>&emsp;&emsp;&emsp;&emsp;
  				<a class="nav" href="/about">About Us</a>&emsp;&emsp;&emsp;&emsp;
  				<a class="nav" href="/contact">Contact</a>&emsp;&emsp;&emsp;&emsp;
  				<a class="nav" href="/login">Login</a>&emsp;&emsp;&emsp;&emsp;
  				<a class="nav" href="/register">Register</a>
	</nav>
</header>
<body>
		<center>
		<table cellspacing="0">
			<tr>
		<td>
		<img src="image/logo.png" width="25%">
		<br>
		<b>LOG IN</b>
		<br>
		<br>
		Email&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;
		<br>
		<input type="text" name="email"  size="23">
		<br>
		<br>
		Password&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;
		<br>
		<input type="Password" name="pass" size="23">
		<br>
		<br>
		<button class="button">Log In</button>
			</td></tr>

		</table>
		<br><br><br>	
		</center>


</body>
<footer>
	<br>
		<img src="image/logo.png" width="3%">&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<br>
  		Copyright © 2020 A.M.A &emsp;&emsp;&emsp;&emsp;HOME | ABOUT US | CONTACT | LOGIN | REGISTER&emsp;&emsp;&emsp;&emsp;Follow Us | <img src="image/fb.png" width="1%"> <img src="image/tw.png" width="1%"> <img src="image/ig.png" width="1%"><br>All Rigths Reserved&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
  		<br>
	
</footer>




</html>