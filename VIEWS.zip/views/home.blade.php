


<!DOCTYPE html>
<html>
<head>
	<title>Website</title>
	<link rel="icon" href="image/logo.png">
	<link href="/css/design.css" rel="stylesheet">
</head>
<header>
	<nav id="nav"><br>
				<a class="Home" href="/home">Home</a>&emsp;&emsp;&emsp;&emsp;
  				<a class="nav" href="/about">About Us</a>&emsp;&emsp;&emsp;&emsp;
  				<a class="nav" href="/contact">Contact</a>&emsp;&emsp;&emsp;&emsp;
  				<a class="nav" href="/login">Login</a>&emsp;&emsp;&emsp;&emsp;
  				<a class="nav" href="/register">Register</a>
	</nav>
</header>
<body>
	<br><br><br><br>
	<center>
		<img src="image/logo.png" width="15%">
		<br><br>
		<img src="image/Tag.png" width="30%">
	</center>
	<br><br><br>
	<br><br><br>
	<br><br><br>
		
</body>
<footer>
	<br>
		<img src="image/logo.png" width="3%">&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<br>
  		Copyright © 2020 A.M.A &emsp;&emsp;&emsp;&emsp;HOME | ABOUT US | CONTACT | LOGIN | REGISTER&emsp;&emsp;&emsp;&emsp;Follow Us | <img src="image/fb.png" width="1%"> <img src="image/tw.png" width="1%"> <img src="image/ig.png" width="1%"><br>All Rigths Reserved&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
  		<br>
	
</footer>

</html>