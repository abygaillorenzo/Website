


<!DOCTYPE html>
<html>
<head>
	<title>About Us</title>
	<link rel="icon" href="image/logo.png">
	<link href="/css/design.css" rel="stylesheet">
</head>
<header>
	<nav id="nav"><br>
				<a class="Home" href="/home">Home</a>&emsp;&emsp;&emsp;&emsp;
  				<a class="nav" href="/about">About Us</a>&emsp;&emsp;&emsp;&emsp;
  				<a class="nav" href="/contact">Contact</a>&emsp;&emsp;&emsp;&emsp;
  				<a class="nav" href="/login">Login</a>&emsp;&emsp;&emsp;&emsp;
  				<a class="nav" href="/register">Register</a>
	</nav>
</header>
<body>
	<center>
	<br><br><br>
		<p>We are The A.M.A group<br>This website contains Infromation about<br> our group project</p>
	<br><br>

	</center>

	<div class="profile">
		<center>
		<img src="image/ab.jpg" alt="ab" width="10%">&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
		<img src="image/ad.png" alt="ad" width="10% ">&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
		<img src="image/mk.png" alt="mk" width="10%">
		<br>
		<p>&emsp;Lorenzo, Abygail&emsp;&emsp;&emsp;
		&emsp;Veloria, Adrian &emsp;&emsp;&emsp;&emsp;
		Rimas, Mary Kane
		<br>
		<div class="group">
		(Group Member)&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
		(Group Leader)&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
		(Group Member)
		</div>
		</p>
		<br>
		<img src="image/fb.png" width="2%"> <img src="image/gm.png" width="2%"> <img src="image/ig.png" width="2%"
		>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;

		<img src="image/fb.png" width="2%"> <img src="image/gm.png" width="2%"> <img src="image/ig.png" width="2%">&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;

		<img src="image/fb.png" width="2%"> <img src="image/gm.png" width="2%"> <img src="image/ig.png" width="2%">
		<br><br><br><br>

		</center>
	</div>
</body>
<footer>
	<br>
		<img src="image/logo.png" width="3%">&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<br>
  		Copyright © 2020 A.M.A &emsp;&emsp;&emsp;&emsp;HOME | ABOUT US | CONTACT | LOGIN | REGISTER&emsp;&emsp;&emsp;&emsp;Follow Us | <img src="image/fb.png" width="1%"> <img src="image/tw.png" width="1%"> <img src="image/ig.png" width="1%"><br>All Rigths Reserved&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
  		<br>
	
</footer>

</html>