<!DOCTYPE html>
<html>
<head>
	<title>Contact</title>
	<link rel="icon" href="image/logo.png">
	<link href="/css/design.css" rel="stylesheet">
</head>
<header>
	<nav id="nav"><br>
				<a class="Home" href="/home">Home</a>&emsp;&emsp;&emsp;&emsp;
  				<a class="nav" href="/about">About Us</a>&emsp;&emsp;&emsp;&emsp;
  				<a class="nav" href="/contact">Contact</a>&emsp;&emsp;&emsp;&emsp;
  				<a class="nav" href="/login">Login</a>&emsp;&emsp;&emsp;&emsp;
  				<a class="nav" href="/register">Register</a>
	</nav>
</header>
<body>
	<br><br><br><br>
	<label>

			L&nbsp;O&nbsp;C&nbsp;A&nbsp;T&nbsp;I&nbsp;O&nbsp;N
			<br>

	</label>
	<br><br>

	<b>San Vicente West, Urdaneta, Pangasinan</b>
	<br>
	<b>A.M.A@gmail.com &nbsp; | &nbsp;+639467304213</b>
	<br><br>
	<img src="image/map.png" class="img2">

	<br><br><br><br><br><br>
	<label> F&nbsp;O&nbsp;L&nbsp;L&nbsp;O&nbsp;W&nbsp;| &nbsp;U&nbsp;S</label><br>
	<label><img src="image/fb.png" width="2%"> <img src="image/tw.png" width="2%"> <img src="image/ig.png" width="2%"><br></label>
	<b>©2020 Privacy policy</b>

	<div class="contact">

					C&nbsp;O&nbsp;N&nbsp;T&nbsp;A&nbsp;C&nbsp;&nbsp;T&emsp;U&nbsp;S
					<br>
					<br>
					Enter your Name<br><input type="text" name="name"  size="40">
					<br>
					Enter your vali email address<br><input type="text" name="email"size="40">
					<br>
					Enter your message<br><textarea name="message" rows="7" cols="39"></textarea>
					<br>
					<button class="button">SUBMIT</button>
		
	</div>

</body>
<footer>
	<br>
		<img src="image/logo.png" width="3%">&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<br>
  		Copyright © 2020 A.M.A &emsp;&emsp;&emsp;&emsp;HOME | ABOUT US | CONTACT | LOGIN | REGISTER&emsp;&emsp;&emsp;&emsp;Follow Us | <img src="image/fb.png" width="1%"> <img src="image/tw.png" width="1%"> <img src="image/ig.png" width="1%"><br>All Rigths Reserved&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
  		<br>
	
</footer>



</html>